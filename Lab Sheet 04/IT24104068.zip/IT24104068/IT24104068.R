setwd("C:\\Users\\IT24104068\\Desktop\\IT24104068")
# Lab Sheet 04 - Descriptive Statistics
# Registration Number: IT2120

# Step 1: Import the dataset
branch_data <- read.csv("Exercise.txt")

# Step 2: Identify variable types and scales
str(branch_data)
# Sales_X1: Numeric, Ratio
# Advertising_X2: Integer, Ratio
# Years_X3: Integer, Ratio

# Step 3: Boxplot for Sales_X1
boxplot(branch_data$Sales_X1,
        main="Boxplot of Sales_X1",
        ylab="Sales",
        col="lightblue",
        horizontal=TRUE)

# Step 4: Five-number summary and IQR for Advertising_X2
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# Step 5: Function to detect outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Apply function to Years_X3
find_outliers(branch_data$Years_X3)
